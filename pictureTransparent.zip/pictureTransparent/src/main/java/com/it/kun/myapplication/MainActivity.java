package com.it.kun.myapplication;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = getApplicationContext();
        findViewById(R.id.upbutton).setOnClickListener(this);
        findViewById(R.id.downbutton).setOnClickListener(this);
        findViewById(R.id.leftbutton).setOnClickListener(this);
        findViewById(R.id.rightbutton).setOnClickListener(this);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.upbutton:
                Toast.makeText(context,"up",Toast.LENGTH_SHORT).show();
                break;
            case R.id.downbutton:
                Toast.makeText(context,"down",Toast.LENGTH_SHORT).show();
                break;
            case R.id.leftbutton:
                Toast.makeText(context,"left",Toast.LENGTH_SHORT).show();
                break;
            case R.id.rightbutton:
                Toast.makeText(context,"right",Toast.LENGTH_SHORT).show();
                break;
        }
    }
}
